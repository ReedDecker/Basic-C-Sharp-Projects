﻿using CarInsurance.Models;
using Microsoft.EntityFrameworkCore;
using Microsoft.AspNetCore.Mvc; // Add this namespace to resolve 'Controller'
using CarInsurance.Data;
using Microsoft.EntityFrameworkCore.Infrastructure; // Add this namespace to resolve 'ApplicationDbContext'

namespace CarInsurance.Data
{
    public class ApplicationDbContext : DbContext
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options)
            : base(options)
        {
        }

        public DbSet<Insuree> Insurees { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            // Configure precision and scale for the Quote property
            modelBuilder.Entity<Insuree>()
                .Property(i => i.Quote)
                .HasPrecision(18, 2); // Precision: 18 digits, Scale: 2 decimal places
        }
    }

    public class InsureesController : Controller
    {
        private readonly ApplicationDbContext _context;

        public InsureesController(ApplicationDbContext context)
        {
            _context = context;
        }

        // Rest of the code remains unchanged
    }
}

namespace CarInsurance.Migrations
{
    [DbContext(typeof(ApplicationDbContext))]
    partial class ApplicationDbContextModelSnapshot : ModelSnapshot
    {
        // Removed duplicate BuildModel method
    }
}
