﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace CarInsurance.Migrations
{
    /// <inheritdoc />
    public partial class InitialCreate : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
                migrationBuilder.CreateTable(
           name: "Insurees",
           columns: table => new
           {
               Id = table.Column<int>(nullable: false)
                   .Annotation("SqlServer:Identity", "1, 1"),
               FirstName = table.Column<string>(nullable: true),
               LastName = table.Column<string>(nullable: true),
               EmailAddress = table.Column<string>(nullable: true),
               DateOfBirth = table.Column<DateTime>(nullable: false),
               CarYear = table.Column<int>(nullable: false),
               CarMake = table.Column<string>(nullable: true),
               CarModel = table.Column<string>(nullable: true),
               DUI = table.Column<bool>(nullable: false), // Ensure this is bool
               SpeedingTickets = table.Column<int>(nullable: false),
               CoverageType = table.Column<bool>(nullable: false) // Ensure this is bool
           },
           constraints: table =>
           {
               table.PrimaryKey("PK_Insurees", x => x.Id);
           });
            }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "Insurees");
        }
    }
}
